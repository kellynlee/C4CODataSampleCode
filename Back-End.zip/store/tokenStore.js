const token = {
    access_token: '',
    expire: ''
};

const JSSDK = {
    token: '',
    expire: ''
}

module.exports = {
    wxToken: token,
    JSSDK: JSSDK,
}